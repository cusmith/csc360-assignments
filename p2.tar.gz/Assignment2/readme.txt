Assignment 2 - Csc 360
Curtis Smith - V00180064

How to run:
1) Extract the contents of p2.tar.gz into a single directory.
2) Compile with the makefile using the command: 
	$ make
3) Run PQS with your input file like so:
	$ ./PQS customers.txt

Notes:
-customers.txt can be replaced with any text file found in the same directory
-PQS will only handle a text file that matches the assignment spec, any other format will cause unpredictable behaviour
-an input file is required as your first argument, additional arguments will be ignored
-program output matches exactly that of the assignment requirements, please check code for comments if looking for additional insight

Feel free to contact me at curtis.smith8@gmail.com if you have any questions or comments.

Thanks!