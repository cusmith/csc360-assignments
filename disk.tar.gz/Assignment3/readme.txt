Assignment 3 - Csc 360
Curtis Smith - V00180064

How to run:
1) Extract the contents of disk.tar.gz into a single directory.
2) Compile with the makefile using the command: 
	$ make
3) Run PQS with your input file like so:
	$ ./diskinfo diskx.IMA
	$ ./disklist diskx.IMA
	$ ./diskget diskx.IMA SOMEFILE.PDF
	$ ./diskput diskx.IMA SOMETEXT.TXT

Notes:
-input files are case sensitive, please use all capitals
-diskput is not working correctly, my code has been submitted in hopes of part marks, but I simply did not leave myself enough time to get things working
-this was the first assignment for which I did not leave time to test on the UVic machines.  I am hoping things transfer over correctly (I am on OSX), but I accept responsibility if things break because of my lack of testing (the first 3 sections work on my computer)

Feel free to contact me at curtis.smith8@gmail.com if you have any questions.

Thanks!